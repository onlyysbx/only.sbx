import { useState } from "react";
import { motion } from "framer-motion";
import { Heart } from "lucide-react";

export default function MesversarioPage() {
  const [showMessage, setShowMessage] = useState(false);

  return (
    <div className="min-h-screen bg-pink-200 p-6 flex flex-col items-center justify-center space-y-6">
      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-4xl font-bold text-red-600 text-center"
      >
        💖 8 Meses Juntos, Melissa 💖
      </motion.h1>

      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 1 }}
        className="grid grid-cols-1 md:grid-cols-2 gap-6"
      >
        <div className="bg-white rounded-2xl shadow-lg p-4">
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS156bobatOIptKAQByJeD-E73eIz4tCD-upw&s" alt="Hello Kitty" className="rounded-xl w-full h-60 object-contain" />
          <p className="text-center text-pink-600 mt-2">Hello Kitty te ama 💕</p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-4">
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRK6zGhC9lJG5EDzGAeiNC3Ym6j_X_WObZD5A&s" alt="Spiderman" className="rounded-xl w-full h-60 object-contain" />
          <p className="text-center text-blue-600 mt-2">Tu Spiderman siempre contigo 🕷️❤️</p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-4">
          <img src="https://previews.123rf.com/images/nyankou/nyankou2201/nyankou220100009/180840091-conjunto-de-elementos-de-garabato-para-el-día-de-san-valentín-cartas-declaraciones-de-amor.jpg" alt="Corazon y amor" className="rounded-xl w-full h-60 object-cover" />
          <p className="text-center text-red-500 mt-2">Amor por to’ los laos ❤️</p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-4">
          <img src="https://upload.wikimedia.org/wikipedia/commons/7/77/Mi_Coraz%C3%B3n_Es_Tuyo.png" alt="Hello Kitty Corazon" className="rounded-xl w-full h-60 object-cover" />
          <p className="text-center text-pink-400 mt-2">Todo mi corazón es tuyo 💘</p>
        </div>
      </motion.div>

      <div className="w-full max-w-4xl mt-12">
        <h2 className="text-2xl font-bold text-center text-red-500 mb-4">📸 Nuestros Recuerdos</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <img src="https://i.imgur.com/QCHSWpB.png" alt="Recuerdo 1" className="rounded-xl object-cover h-60 w-full" />
          <img src="https://i.imgur.com/BvEZDnT.png" alt="Recuerdo 2" className="rounded-xl object-cover h-60 w-full" />
          <img src="https://i.imgur.com/1VL7BJ4.png" alt="Recuerdo 3" className="rounded-xl object-cover h-60 w-full" />
        </div>
      </div>

      <button onClick={() => setShowMessage(true)} className="bg-red-500 text-white px-6 py-2 rounded-full hover:bg-red-600 mt-6">
        Ver Mensajito 💌
      </button>

      {showMessage && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
          className="bg-white p-6 rounded-xl shadow-lg max-w-xl text-center mt-6"
        >
          <p className="text-lg text-gray-700">
            Mi amor, ya son 8 meses a tu lao’ y me siento como si el tiempo volara cada vez que te veo sonreír. E’ increíble cómo Hello Kitty y Spiderman pueden tener algo en común: los dos tan enamorao’ de ti 😘. Gracias por todo, por tu paciencia, tu cariño y por ser la mejor parte de mi día. ¡Vamos pa’ mucho más! 💖🕷️
            <br /><br />
            En estos 8 meses hemos creado recuerdos que valen oro, y cada risa contigo es mi canción favorita. Tú eres mi Kitty linda y yo tu Spiderman que nunca te suelta. Te amo más de lo que las palabras pueden decir. 💘🥹
          </p>
        </motion.div>
      )}
    </div>
  );
}